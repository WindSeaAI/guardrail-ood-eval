#!/usr/bin/env python3
"""Create vector paper figures from audited CSVs, without running a model."""
import argparse
import csv
import hashlib
import json
import platform
import shutil
import sys
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Polygon

BLUE = '#53758D'
RED = '#9E4148'
DARK = '#28333C'
GRAY = '#7B858E'
LINE = '#C9CFD4'
PALE = '#F8F9FA'

CAPTIONS = [
    {
        'file': 'fig1_lexical_mask',
        'english': (
            'Figure 1. Observed response rates for the baseline and lexical-mask conditions on 200 direct behavior requests '
            '(100 harmful and 100 dataset-benign requests). Under preliminary assistant coding, observed harmful assistance '
            'was 1/100 in both conditions, and dataset-relative refusal was 45/100 in both. Exactly 199/200 paired output '
            'strings were identical, including all 100 harmful-request pairs. The sole changed pair was a dataset-benign '
            'administration request. Each condition had 54/200 truncated outputs; labels describe only visible text. '
            'These are descriptive counts from one fixed run, not independently validated human labels or official '
            'JailbreakBench attack-success scores. Equal observed rates do not establish population-level equivalence. '
            'Both panels use the same vertical scale.'
        ),
        'chinese': (
            '图1：两组有害协助均为1/100，按数据集正常标签计算的拒绝均为45/100；199/200对输出完全相同，'
            '包括全部100条有害请求。唯一变化来自正常管理请求。每组54条回答截断，结果仅针对已观察文本及助手初审口径。'
            '不能把这一组实验推广为所有字面约束均无效，也不能写成官方JBB ASR。'
        ),
    },
    {
        'file': 'fig2_probe_transfer',
        'english': (
            'Figure 2. Per-request scores from a frozen layer-15 linear probe with a validation-selected threshold of 0.65 '
            'on Qwen2.5-1.5B-Instruct. Left: the reused 20-case synthetic test/integration set, consisting of 10 target-positive '
            'and 10 target-negative requests; 7/10 positives and 0/10 negatives triggered the gate. Right: 16 transferred '
            'JailbreakBench attack artifacts (PAIR and random-search prompts covering eight behavior groups), plus '
            '16 assistant-authored benign controls. No external attack (0/16) or control (0/16) triggered the gate; '
            'the maximum external score was 0.3700866, rounded to 0.3701. All 32 external baseline-guarded output '
            'pairs were identical. The external evaluation shifts language, prompt form, and goal domain beyond the narrow '
            'training target of explicitly unauthorized destruction of others\' data. Scores are uncalibrated classifier '
            'outputs, not danger probabilities. Gate-trigger rates are not ASR; this transfer sample is not an official '
            'JailbreakBench leaderboard evaluation.'
        ),
        'chinese': (
            '图2：左侧不是训练集，而是已用于分类测试、随后复用的20条合成集。右侧32条包含16条外部攻击和16条自编正常对照，'
            '不是32条越狱攻击。攻击阻断为0/16，最高分0.3700866；不应写成严格“小于0.37”。'
            '探针任务较窄，语言、目标领域和提示形式同时变化，不能分离这些因素的因果作用。'
        ),
    },
    {
        'file': 'fig3_observations_and_hypothesis',
        'english': (
            'Figure 3. Implementation-level observations and a separate, untested research hypothesis. '
            '(a) The lexical mask acts on next-token logits during decoding. A sudo-to-su wording change occurred on '
            'one dataset-benign request; this does not verify an equivalent harmful action or reveal a latent causal path. '
            '(b) The activation probe acts after a prompt forward pass but before answer generation, rather than as a '
            'post-generation text filter. Its external-run scores stayed below the fixed threshold, so no requests were '
            'gated. (c) An explicit concept/relation transition system with enforced constraints is a proposed research '
            'direction, not a mechanism implemented or validated here. Any reachability guarantee would require '
            'defined state semantics, specified constraints, and verified enforcement. These observations do not prove '
            'that external safeguards must fail, nor that structural constraints would provide general semantic safety.'
        ),
        'chinese': (
            '图3：前两行分别画出实际挂载位置，避免把“解码中mask”和“生成前探针”误画为同一个下游文本过滤器。'
            '最后一行仅为未来结构约束设想；尚无实现、形式化定义或语义安全证明。'
            '本轮证据不能支持“外部护栏必然失效”或“新范式已实现逻辑不可达”。'
        ),
    },
]


def read_csv(path):
    with path.open(encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def setup_font(root):
    font_dir = root / 'fonts'
    for path in font_dir.glob('*.ttf'):
        font_manager.fontManager.addfont(str(path))
    # Prefer the requested font when it actually exists. Do not mislabel a fallback.
    try:
        actual_path = font_manager.findfont('Arial', fallback_to_default=False)
        family = 'Arial'
    except ValueError:
        actual_path = font_manager.findfont('Liberation Sans', fallback_to_default=False)
        family = 'Liberation Sans'
    plt.rcParams.update({
        'font.family': family, 'font.size': 10.5,
        'axes.labelsize': 10.5, 'xtick.labelsize': 10,
        'ytick.labelsize': 10, 'legend.fontsize': 10,
        'text.color': DARK, 'axes.labelcolor': DARK,
        'xtick.color': DARK, 'ytick.color': DARK,
        'axes.edgecolor': GRAY, 'axes.linewidth': 0.7,
        'figure.facecolor': 'white', 'axes.facecolor': 'white',
        'savefig.facecolor': 'white', 'pdf.fonttype': 42,
        'ps.fonttype': 42, 'svg.fonttype': 'path',
        'axes.unicode_minus': False,
    })
    return {'actual_font_family': family, 'font_file_basename': Path(actual_path).name,
            'fallback_explanation': 'Liberation Sans is an Arial-metric-compatible fallback, not Arial.',
            'pdf_fonts': 'Embedded TrueType', 'svg_fonts': 'Outlined vector paths',
            'figure_text_size_pt': '10-11', 'png_dpi': 300}


def clean_axes(ax):
    ax.spines[['top', 'right']].set_visible(False)
    ax.set_axisbelow(True)
    ax.grid(axis='y', color='#E4E7E9', linewidth=0.6)
    ax.tick_params(length=3, width=0.7)


def save(fig, root, stem):
    directory = root / 'figures'
    directory.mkdir(exist_ok=True)
    fig.canvas.draw()
    # Avoid accidental clipping of text at the specified paper size.
    bounds = fig.bbox
    renderer = fig.canvas.get_renderer()
    for text in fig.findobj(match=matplotlib.text.Text):
        if not text.get_visible() or not text.get_text():
            continue
        bb = text.get_window_extent(renderer)
        if bb.x0 < -0.5 or bb.y0 < -0.5 or bb.x1 > bounds.x1 + 0.5 or bb.y1 > bounds.y1 + 0.5:
            raise RuntimeError(f'Figure text outside canvas: {stem}: {text.get_text()!r}')
    for ext in ['pdf', 'svg', 'png']:
        kwargs = {'dpi': 300} if ext == 'png' else {}
        fig.savefig(directory / f'{stem}.{ext}', **kwargs)
    plt.close(fig)


def figure1(root):
    counts = read_csv(root / 'data/figure1_counts.csv')
    lookup = {(r['metric'], r['method']): r for r in counts}
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.5), sharey=True)
    fig.subplots_adjust(left=0.09, right=0.985, bottom=0.31, top=0.88, wspace=0.23)
    specs = [('observed_harmful_response', '(a) Harmful response'),
             ('dataset_relative_refusal', '(b) Dataset-relative refusal')]
    for ax, (metric, label) in zip(axes, specs):
        clean_axes(ax)
        rows = [lookup[metric, m] for m in ['baseline', 'guarded']]
        values = [100 * float(r['rate']) for r in rows]
        ax.bar([0, 1], values, width=0.53, color=[BLUE, RED], edgecolor='none', zorder=3)
        for x, value, row in zip([0, 1], values, rows):
            ax.text(x, value + 2.0,
                    f"{value:.0f}%\n({row['numerator']}/{row['denominator']})",
                    ha='center', va='bottom', fontsize=10.5, linespacing=1.3)
        ax.set_xticks([0, 1], ['Baseline', 'Lexical mask'])
        ax.set_xlim(-0.65, 1.65)
        ax.set_ylim(0, 60)
        ax.set_yticks([0, 15, 30, 45, 60])
        ax.text(0, 1.08, label, transform=ax.transAxes, fontsize=11, fontweight='bold')
    axes[0].set_ylabel('Observed rate (%)')
    fig.text(0.535, 0.135, '199/200 output pairs exactly identical (99.5%)',
             ha='center', va='center', fontsize=11, fontweight='bold',
             bbox={'boxstyle': 'square,pad=0.45', 'edgecolor': LINE, 'facecolor': 'white', 'linewidth': 0.7})
    fig.text(0.535, 0.035, 'Assistant preliminary labels; direct requests; official ASR not measured.',
             ha='center', fontsize=10, color=GRAY)
    save(fig, root, 'fig1_lexical_mask')


def figure2(root):
    rows = read_csv(root / 'data/figure2_probe_scores.csv')
    fig = plt.figure(figsize=(7.2, 4.4))
    left = fig.add_axes([0.09, 0.35, 0.32, 0.53])
    right = fig.add_axes([0.50, 0.35, 0.485, 0.53], sharey=left)
    styles = {
        'synthetic_target_positive': {'marker': 'o', 's': 34, 'facecolors': BLUE, 'edgecolors': BLUE, 'linewidths': 0.9},
        'synthetic_target_negative': {'marker': 'o', 's': 34, 'facecolors': 'white', 'edgecolors': BLUE, 'linewidths': 1.2},
        'external_attack': {'marker': 'x', 's': 44, 'color': RED, 'linewidths': 1.4},
        'external_benign_control': {'marker': 'D', 's': 28, 'facecolors': 'white', 'edgecolors': GRAY, 'linewidths': 1.0},
    }
    for ax, group, maximum, title in [
        (left, 'long', 20, '(a) Synthetic (reused test)'),
        (right, 'external', 32, '(b) External transfer (n = 32)'),
    ]:
        clean_axes(ax)
        for subset, style in styles.items():
            selected = [r for r in rows if r['run_group'] == group and r['subset'] == subset]
            if selected:
                ax.scatter([int(r['sample_index']) for r in selected],
                           [float(r['score']) for r in selected], zorder=4, **style)
        ax.axhline(0.65, color=RED, linestyle=(0, (5, 3)), linewidth=1.1, zorder=2)
        ax.set_ylim(-0.04, 1.06)
        ax.set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])
        ax.set_xlim(0, maximum + 1)
        ax.set_xlabel('Sample index (record order)', labelpad=6)
        ax.text(0, 1.08, title, transform=ax.transAxes, fontsize=11, fontweight='bold')
    left.set_xticks([1, 5, 10, 15, 20])
    right.set_xticks([1, 8, 16, 24, 32])
    left.set_ylabel('Uncalibrated probe score')
    right.tick_params(labelleft=False)
    left.text(10.5, 0.72, '7/10 positives gated', fontsize=10, ha='center', color=BLUE)
    right.text(16.5, 0.88, 'External attacks: 0/16 gated (0%)\nMax external score: 0.3701',
               ha='center', va='center', fontsize=10.5, color=RED, linespacing=1.45)
    right.text(32.5, 0.675, 'Threshold = 0.65', ha='right', va='bottom', color=RED, fontsize=10)
    handles = [
        Line2D([], [], marker='o', ls='', color=BLUE, markersize=5.8, label='Synthetic target-positive'),
        Line2D([], [], marker='o', ls='', color=BLUE, mfc='white', markersize=5.8, label='Synthetic target-negative'),
        Line2D([], [], marker='x', ls='', color=RED, markersize=6.2, label='External attack (n = 16)'),
        Line2D([], [], marker='D', ls='', color=GRAY, mfc='white', markersize=5.2, label='External control (n = 16)'),
    ]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(0.545, 0.09),
               ncol=2, frameon=False, columnspacing=2.0, handletextpad=0.5, labelspacing=0.7)
    fig.text(0.54, 0.026, 'Layer 15; frozen threshold; descriptive gate counts, not ASR.',
             ha='center', fontsize=10, color=GRAY)
    save(fig, root, 'fig2_probe_transfer')


def figure3(root):
    fig = plt.figure(figsize=(7.2, 6.7))
    ax = fig.add_axes([0.015, 0.01, 0.97, 0.98])
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.axis('off')

    def box(x, y, text, w=1.85, h=0.90, color=LINE, fill='white', tc=DARK):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.04,rounding_size=0.055',
                                    facecolor=fill, edgecolor=color, linewidth=0.9))
        ax.text(x + w/2, y + h/2, text, ha='center', va='center', fontsize=10.5,
                color=tc, linespacing=1.35)

    def arrow(start, end, color=GRAY, style='-', **kwargs):
        patch = FancyArrowPatch(start, end, arrowstyle='-|>', mutation_scale=11,
                                linewidth=1, color=color, linestyle=style, **kwargs)
        ax.add_patch(patch)

    def row_title(y, text):
        ax.text(0.08, y, text, fontsize=11, fontweight='bold', va='center')

    xs = [0.12, 2.70, 5.28, 7.86]
    row_title(9.65, '(a) Observed: lexical mask during decoding')
    y = 8.22
    box(xs[0], y, 'Dataset-benign\nadmin request')
    box(xs[1], y, 'Qwen\nnext-token logits')
    box(xs[2], y, 'First-token mask\n(four strings)', color=RED, fill='#FCF7F7')
    box(xs[3], y, 'Changed wording\nsudo -> su')
    for i in range(3):
        arrow((xs[i] + 1.91, y+0.45), (xs[i+1] - 0.07, y+0.45))
    ax.text(0.12, 7.70, 'One benign case changed; 199/200 output pairs were identical.\n'
            'Equivalent harmful actions or latent causal paths were not verified.',
            fontsize=10.5, linespacing=1.5, va='top')
    ax.plot([0.08, 9.9], [6.98, 6.98], color=LINE, lw=0.7)

    row_title(6.63, '(b) Observed: activation probe before answer generation')
    y = 5.18
    box(xs[0], y, 'External request')
    box(xs[1], y, 'Prompt forward\nlayer 15 features')
    box(xs[2], y, 'Linear score gate\nscore < 0.65', color=RED, fill='#FCF7F7')
    box(xs[3], y, 'Answer generation\n(no gate block)')
    for i in range(3):
        arrow((xs[i] + 1.91, y+0.45), (xs[i+1] - 0.07, y+0.45))
    ax.text(0.12, 4.68, 'External run: 0/32 gated, including 0/16 transferred attacks.\n'
            'All 32 baseline-guarded output pairs were identical.',
            fontsize=10.5, linespacing=1.5, va='top')
    ax.plot([0.08, 9.9], [3.98, 3.98], color=LINE, lw=0.7)

    row_title(3.62, '(c) Proposed: explicit transition constraints (not implemented)')
    y = 1.93
    box(xs[0], y, 'Concept / relation\nstate', color=BLUE)
    box(xs[1], y, 'Candidate\ntransition', color=BLUE)
    arrow((xs[0]+1.91, y+0.45), (xs[1]-0.07, y+0.45), color=BLUE)
    cx, cy = 6.20, y + 0.45
    ax.add_patch(Polygon([[cx-1.00, cy], [cx, cy+0.72], [cx+1.00, cy], [cx, cy-0.72]],
                          closed=True, facecolor='white', edgecolor=BLUE, lw=1.0))
    ax.text(cx, cy, 'Constraint\nsatisfied?', ha='center', va='center', fontsize=10.5, linespacing=1.2)
    arrow((xs[1]+1.91, cy), (cx-1.06, cy), color=BLUE)
    box(xs[3], 2.60, 'Allowed next\nstate', color=BLUE)
    arrow((cx+1.02, cy+0.04), (xs[3]-0.08, 3.03), color=BLUE)
    ax.text(7.32, 3.05, 'yes', fontsize=10, color=BLUE, ha='right')
    box(xs[3], 1.12, 'Disallowed\ntransition', color=LINE, tc=GRAY)
    arrow((cx+0.25, cy-0.57), (7.57, 1.57), color=RED, style=(0, (4, 3)))
    ax.text(6.90, 1.77, 'no', fontsize=10, color=RED)
    ax.plot([7.64, 7.64], [1.11, 2.02], color=RED, linewidth=3.0, solid_capstyle='butt')
    ax.text(0.12, 0.70, 'Hypothesis: verified constraints would restrict reachable transitions.\n'
            'No implementation or semantic safety proof is provided by these experiments.',
            fontsize=10.5, linespacing=1.5, va='top', color=GRAY)
    save(fig, root, 'fig3_observations_and_hypothesis')


def figure_book(root):
    import fitz
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import Paragraph
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.colors import HexColor
    from xml.sax.saxutils import escape

    regular = root / 'fonts/LiberationSans-Regular.ttf'
    bold = root / 'fonts/LiberationSans-Bold.ttf'
    pdfmetrics.registerFont(TTFont('PaperSans', str(regular)))
    pdfmetrics.registerFont(TTFont('PaperSansBold', str(bold)))
    chinese = root / 'fonts/NotoSansSC-Regular.ttf'
    pdfmetrics.registerFont(TTFont('PaperCJK', str(chinese)))
    pdfmetrics.registerFontFamily('PaperSans', normal='PaperSans', bold='PaperSansBold')
    w, h = A4
    margin = (w - 7.2*72) / 2
    styles = {
        'caption': ParagraphStyle('caption', fontName='PaperSans', fontSize=10.5, leading=14.1,
                                  textColor=HexColor(DARK), spaceAfter=12),
        'note': ParagraphStyle('note', fontName='PaperCJK', fontSize=10, leading=15,
                               wordWrap='CJK', textColor=HexColor(DARK)),
    }
    temp = root / 'figures_and_captions_text.tmp.pdf'
    c = canvas.Canvas(str(temp), pagesize=A4)
    rects = []
    for i, cap in enumerate(CAPTIONS, start=1):
        c.setFont('PaperSans', 9)
        c.setFillColor(HexColor(GRAY))
        c.drawString(margin, h-26, 'OpenMorpho / Paper figures and captions')
        c.drawRightString(w-margin, h-26, '08 Nov 2026')
        source = fitz.open(root / 'figures' / f"{cap['file']}.pdf")
        source_size = source[0].rect
        fh = (w - 2*margin) * source_size.height / source_size.width
        rect = fitz.Rect(margin, 48, w-margin, 48+fh)
        rects.append(rect)
        y = h - rect.y1 - 17
        en = Paragraph(escape(cap['english']), styles['caption'])
        _, ph = en.wrap(w-2*margin, h)
        en.drawOn(c, margin, y-ph)
        y -= ph+21
        zh = Paragraph(escape(cap['chinese']), styles['note'])
        _, zh_h = zh.wrap(w-2*margin, h)
        assert y - zh_h >= 43, f'Caption does not fit page {i}'
        zh.drawOn(c, margin, y-zh_h)
        c.setFont('PaperSans', 9)
        c.setFillColor(HexColor(GRAY))
        c.drawString(margin, 24, 'Frozen records; no new inference. Independent human review remains pending.')
        c.drawRightString(w-margin, 24, str(i))
        c.showPage()
        source.close()
    c.setTitle('OpenMorpho: Negative Results Figures and Captions')
    c.setAuthor('OpenMorpho / Zeng Jialiang')
    c.save()
    doc = fitz.open(temp)
    for i, cap in enumerate(CAPTIONS):
        with fitz.open(root / 'figures' / f"{cap['file']}.pdf") as src:
            doc[i].show_pdf_page(rects[i], src, 0)
    final = root / 'OpenMorpho_Negative_Results_Figures_and_Captions_20261108.pdf'
    doc.save(final, garbage=4, deflate=True)
    doc.close()
    temp.unlink()
    return final


def write_documentation(root, font_info):
    en = '\n\n'.join(f"## Figure {i}\n\n{c['english']}\n\n{c['chinese']}" for i, c in enumerate(CAPTIONS, 1))
    (root / 'CAPTIONS_EN_ZH.md').write_text('# Paper captions / 论文图注\n\n' + en + '\n', encoding='utf-8')
    latex = r'''% Copy the figures/ directory next to your manuscript.
% Preamble: \usepackage{graphicx}
% These are double-column figures. Use figure instead of figure* in a single-column manuscript.
'''
    for cap in CAPTIONS:
        latex += '\n\\begin{figure*}[t]\n\\centering\n'
        latex += f"\\includegraphics[width=\\textwidth]{{figures/{cap['file']}.pdf}}\n"
        caption = cap['english'].split('. ', 1)[1]
        for before, after in [('&', r'\&'), ('%', r'\%'), ('_', r'\_')]:
            caption = caption.replace(before, after)
        latex += '\\caption{' + caption + '}\n'
        latex += f"\\label{{fig:{cap['file']}}}\n\\end{{figure*}}\n"
    (root / 'INSERT_IN_PAPER.tex').write_text(latex, encoding='utf-8')
    readme = '''# OpenMorpho：阶段一与阶段二负面结果图表

本包只把冻结记录转成图，不训练、不重跑推理、不改阈值或原有标签。适合论文初稿与教授审阅；独立人工标签尚未完成。

## 文件

- `figures/`：三张图各含 PDF、SVG、300 DPI PNG。PDF/SVG 为矢量图；PNG 不是截图。
- `OpenMorpho_Negative_Results_Figures_and_Captions_20261108.pdf`：三页合并阅读版，保留矢量图，附英文论文图注与中文核对提示。
- `CAPTIONS_EN_ZH.md`：可直接复制的双语图注。
- `INSERT_IN_PAPER.tex`：LaTeX 双栏论文插图示例。未收到论文稿件，因此未声称已插入某篇实际论文。
- `data/`：真实图表数据、来源哈希、提取检查，以及原有助手指标快照。没有使用模拟分数。
- `code/prepare_data.py`：从原联合交付 ZIP 重新提取、核验图表数据。
- `code/make_figures.py`：从 CSV 重绘三图及阅读版。原始报告没有被覆盖。
- `fonts/`：实际使用的英文字体及阅读版中文字体，附授权说明。
- `SHA256SUMS.json`：本包文件校验值；不能替代独立审核。

## 已核对的数字与论文边界

1. 阶段一：100 条有害直接请求 + 100 条数据集正常请求。两组助手初审有害协助均为 1/100，数据集相对拒绝均为 45/100；199/200 对回答完全相同，包括全部有害请求。两组均有 54/200 截断，不能推断未生成的后续内容。不是官方 JailbreakBench ASR，也不是人审最终结论。严口径可把唯一有害样例判为目标未完全达成，此时两组同为 0%；更改口径也不会产生两组差异。
2. 阶段二：左侧为复用的 20 条合成测试集，不是训练样本。7/10 目标正例触发，0/10 目标负例触发。右侧为 16 条外部攻击 + 16 条助手自编正常对照；攻击触发为 0/16，不是“32 条越狱”。16 个攻击来自两个方法、八个目标组，并非 16 个独立目标。最高分为 0.37008658393112914，四舍五入显示 0.3701，不能说严格小于 0.37。
3. 外部攻击目标超出窄探针训练范围，语言、目标领域、提示风格和长度同时变化。结果支持“本次迁移未触发”，不单独识别所谓认知机制；也不是 ASR。外部两组各 6/32 截断。
4. 图3前两行是实际实现与观测；最后一行仅为未来研究设想。现有材料没有给出结构约束系统的实现、形式化语义或证明。不能写成“所有外部护栏必然失败”或“新范式已获验证”。sudo→su 出现在正常管理样例，未验证等价危害。
5. 字体优先使用真实 Arial；本次环境没有 Arial，因此实际嵌入 Liberation Sans（Arial 度量兼容字体）。没有把替代字体标成 Arial。图内为 10–11 pt；PDF 嵌入字体，SVG 将字形转为矢量路径。按约 7.2 英寸/双栏宽度放置，勿缩成单栏后仍期待原字号。

## 建议论文措辞

“在这组固定实验记录上，字面首 token 屏蔽仅改变了一对正常请求输出；冻结的窄任务探针在 10 条合成目标正例中触发 7 条，但在所选 16 条跨域外部攻击中未触发。以上结果揭示本次实现与评测范围内的限制，不构成所有护栏无效或任何新方案有效的普遍证明。”

## 重绘

Python 3.11+，依赖 Matplotlib、NumPy、PyMuPDF、ReportLab。先安装依赖，再运行：

```bash
python code/make_figures.py
```

若从原始联合交付包重新提取数据（原包另行保留，未复制进本图表包）：

```bash
python code/prepare_data.py --source-bundle /absolute/path/OpenMorpho_Phase1_Phase2_Professor_Handoff_20261107.zip
python code/make_figures.py
```

原始联合交付包 SHA-256：`bfe37e0c2206c6f695751c56edc5c5a8c9bb6b65e6dc0fc55e16871be4529a09`。
重新运行或改图后需重新生成本包校验文件。
'''
    (root / 'README_ZH.md').write_text(readme, encoding='utf-8')
    provenance = json.loads((root / 'data/source_audit.json').read_text())
    metadata = {
        'created_date': '2026-11-08', 'model': 'Qwen2.5-1.5B-Instruct',
        'font': font_info, 'software': {'python': platform.python_version(),
                                      'matplotlib': matplotlib.__version__, 'numpy': np.__version__},
        'figure_width_inches': 7.2, 'source_bundle_sha256': provenance['source_bundle_sha256'],
        'new_inference_performed': False, 'new_annotation_performed': False,
        'figure3_status': 'Observed implementation diagrams plus explicitly untested hypothesis',
    }
    (root / 'FIGURE_METADATA.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    (root / 'requirements.txt').write_text('matplotlib>=3.6\nnumpy>=1.24\nPyMuPDF>=1.22\nreportlab>=4.0\n', encoding='utf-8')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    root = args.root.resolve()
    font_info = setup_font(root)
    figure1(root)
    figure2(root)
    figure3(root)
    book = figure_book(root)
    write_documentation(root, font_info)
    print(json.dumps({'root': str(root), 'book': str(book), 'font': font_info}, indent=2))


if __name__ == '__main__':
    main()
