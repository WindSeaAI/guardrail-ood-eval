#!/usr/bin/env python3
"""Check delivered file integrity. Does not validate scientific conclusions."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
hashes = json.loads((root / 'SHA256SUMS.json').read_text(encoding='utf-8'))
for name, expected in hashes.items():
    path = root / name
    if not path.is_file():
        raise SystemExit(f'MISSING: {name}')
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit(f'MISMATCH: {name}')
print(f'PASS: {len(hashes)} delivered file checksums. No inference or semantic review performed.')
