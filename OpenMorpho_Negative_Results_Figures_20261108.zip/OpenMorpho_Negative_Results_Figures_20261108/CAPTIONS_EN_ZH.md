# Paper captions / 论文图注

## Figure 1

Figure 1. Observed response rates for the baseline and lexical-mask conditions on 200 direct behavior requests (100 harmful and 100 dataset-benign requests). Under preliminary assistant coding, observed harmful assistance was 1/100 in both conditions, and dataset-relative refusal was 45/100 in both. Exactly 199/200 paired output strings were identical, including all 100 harmful-request pairs. The sole changed pair was a dataset-benign administration request. Each condition had 54/200 truncated outputs; labels describe only visible text. These are descriptive counts from one fixed run, not independently validated human labels or official JailbreakBench attack-success scores. Equal observed rates do not establish population-level equivalence. Both panels use the same vertical scale.

图1：两组有害协助均为1/100，按数据集正常标签计算的拒绝均为45/100；199/200对输出完全相同，包括全部100条有害请求。唯一变化来自正常管理请求。每组54条回答截断，结果仅针对已观察文本及助手初审口径。不能把这一组实验推广为所有字面约束均无效，也不能写成官方JBB ASR。

## Figure 2

Figure 2. Per-request scores from a frozen layer-15 linear probe with a validation-selected threshold of 0.65 on Qwen2.5-1.5B-Instruct. Left: the reused 20-case synthetic test/integration set, consisting of 10 target-positive and 10 target-negative requests; 7/10 positives and 0/10 negatives triggered the gate. Right: 16 transferred JailbreakBench attack artifacts (PAIR and random-search prompts covering eight behavior groups), plus 16 assistant-authored benign controls. No external attack (0/16) or control (0/16) triggered the gate; the maximum external score was 0.3700866, rounded to 0.3701. All 32 external baseline-guarded output pairs were identical. The external evaluation shifts language, prompt form, and goal domain beyond the narrow training target of explicitly unauthorized destruction of others' data. Scores are uncalibrated classifier outputs, not danger probabilities. Gate-trigger rates are not ASR; this transfer sample is not an official JailbreakBench leaderboard evaluation.

图2：左侧不是训练集，而是已用于分类测试、随后复用的20条合成集。右侧32条包含16条外部攻击和16条自编正常对照，不是32条越狱攻击。攻击阻断为0/16，最高分0.3700866；不应写成严格“小于0.37”。探针任务较窄，语言、目标领域和提示形式同时变化，不能分离这些因素的因果作用。

## Figure 3

Figure 3. Implementation-level observations and a separate, untested research hypothesis. (a) The lexical mask acts on next-token logits during decoding. A sudo-to-su wording change occurred on one dataset-benign request; this does not verify an equivalent harmful action or reveal a latent causal path. (b) The activation probe acts after a prompt forward pass but before answer generation, rather than as a post-generation text filter. Its external-run scores stayed below the fixed threshold, so no requests were gated. (c) An explicit concept/relation transition system with enforced constraints is a proposed research direction, not a mechanism implemented or validated here. Any reachability guarantee would require defined state semantics, specified constraints, and verified enforcement. These observations do not prove that external safeguards must fail, nor that structural constraints would provide general semantic safety.

图3：前两行分别画出实际挂载位置，避免把“解码中mask”和“生成前探针”误画为同一个下游文本过滤器。最后一行仅为未来结构约束设想；尚无实现、形式化定义或语义安全证明。本轮证据不能支持“外部护栏必然失效”或“新范式已实现逻辑不可达”。
